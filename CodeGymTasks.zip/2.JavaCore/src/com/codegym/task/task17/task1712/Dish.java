package com.codegym.task.task17.task1712;

public class Dish {
    private byte tableNumber;

    public Dish(byte tableNumber) {
        this.tableNumber = tableNumber;
    }

    public byte getTableNumber() {
        return tableNumber;
    }
}
