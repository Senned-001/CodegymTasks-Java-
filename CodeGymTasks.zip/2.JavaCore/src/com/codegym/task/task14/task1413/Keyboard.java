package com.codegym.task.task14.task1413;

public class Keyboard implements CompItem {
    @Override
    public String getName(){
        return "Keyboard";
    }
}
