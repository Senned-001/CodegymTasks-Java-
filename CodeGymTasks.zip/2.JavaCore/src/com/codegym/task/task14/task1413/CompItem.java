package com.codegym.task.task14.task1413;

public interface CompItem {
    String getName();
}
