package com.codegym.task.task14.task1413;

public class Monitor implements CompItem {
    @Override
    public String getName(){
        return "Monitor";
    }
}