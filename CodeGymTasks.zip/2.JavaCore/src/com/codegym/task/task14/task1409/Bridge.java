package com.codegym.task.task14.task1409;

public interface Bridge {
    int getCarsCount();
}