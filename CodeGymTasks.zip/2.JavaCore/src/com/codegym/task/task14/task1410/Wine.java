package com.codegym.task.task14.task1410;

public class Wine extends Drink {
    public String getCelebrationName(){
        return "Birthday";
    }
}
