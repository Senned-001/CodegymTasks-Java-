package com.codegym.task.task14.task1410;

public class BubblyWine extends Wine {
    public String getCelebrationName(){
        return  "New Year's";
    }

}
