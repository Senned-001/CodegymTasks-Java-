package com.codegym.task.task14.task1408;

 abstract class Hen{

     public abstract int getMonthlyEggCount();

    public String getDescription(){
        return "I am a chicken.";
    }
}