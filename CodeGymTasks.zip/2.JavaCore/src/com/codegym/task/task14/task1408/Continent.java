package com.codegym.task.task14.task1408;

public interface Continent {
    String EUROPE = "Europe";
    String NORTHAMERICA = "North America";
    String ASIA = "Asia";
    String AFRICA = "Africa";
}
