package com.codegym.task.task16.task1631.common;

public class BmpReader implements ImageReader {


}
