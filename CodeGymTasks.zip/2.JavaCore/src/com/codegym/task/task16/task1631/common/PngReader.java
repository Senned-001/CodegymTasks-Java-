package com.codegym.task.task16.task1631.common;

public class PngReader implements ImageReader {


}
