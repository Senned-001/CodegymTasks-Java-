package com.codegym.task.task15.task1525;

public class Statics {
    public static String FILE_NAME = "c\\12312";
}
