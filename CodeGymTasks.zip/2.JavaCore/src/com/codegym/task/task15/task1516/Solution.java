package com.codegym.task.task15.task1516;

/* 
Default values

*/

public class Solution {


    public int intVar;
    double doubleVar;
    Double DoubleVar;
    boolean booleanVar;
    Object ObjectVar;
    Exception ExceptionVar;
    String StringVar;
    public static void main(String[] args) {


            Solution my = new Solution();
            System.out.println(my.intVar);
            System.out.println(my.doubleVar);
            System.out.println(my.DoubleVar);
            System.out.println(my.booleanVar);
            System.out.println(my.ObjectVar);
            System.out.println(my.ExceptionVar);
            System.out.println(my.StringVar);

    }
}
