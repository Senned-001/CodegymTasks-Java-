package com.codegym.task.task15.task1530;

public class TeaMaker extends DrinkMaker {

    public void getRightCup(){
        System.out.println("Grab a cup for tea");
    }
    public void addIngredients(){
        System.out.println("Pour tea");
    }
    public void pour(){
        System.out.println("Fill with boiling water");
    }

}
