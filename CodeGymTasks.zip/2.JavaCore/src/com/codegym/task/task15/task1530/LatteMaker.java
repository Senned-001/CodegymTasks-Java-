package com.codegym.task.task15.task1530;

public class LatteMaker extends DrinkMaker {


    public void getRightCup(){
        System.out.println("Grab a cup for latte");
    }
    public void addIngredients(){
        System.out.println("Make coffee");
    }
    public void pour(){
        System.out.println("Fill with foamy milk");
    }

}
