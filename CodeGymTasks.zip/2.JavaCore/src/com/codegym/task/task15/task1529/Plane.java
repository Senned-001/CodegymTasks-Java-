package com.codegym.task.task15.task1529;

public class Plane implements CanFly {
private int num;

public Plane(int num){
    this.num = num;
}
    public void fly(){

    }
}
