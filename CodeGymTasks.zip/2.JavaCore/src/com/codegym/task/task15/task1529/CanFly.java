package com.codegym.task.task15.task1529;

public interface CanFly {
    void fly();
}
