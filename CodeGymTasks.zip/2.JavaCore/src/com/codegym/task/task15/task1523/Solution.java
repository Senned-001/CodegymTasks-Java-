package com.codegym.task.task15.task1523;

/* 
Overloading constructors

*/

public class Solution {


    public static void main(String[] args) {

    }

    public Solution(String name) {
    }

    Solution() {
    }

    private Solution(int i){

    }

    protected Solution(double a){

    }
}

