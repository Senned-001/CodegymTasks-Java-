package com.codegym.task.task15.task1523;

public class SubSolution extends Solution{
    public SubSolution(String name) {
        super(name);
    }

     SubSolution() {
    }

    protected SubSolution(double a) {
        super(a);
    }
}
