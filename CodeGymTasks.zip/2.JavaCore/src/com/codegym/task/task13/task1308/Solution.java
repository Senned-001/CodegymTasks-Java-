package com.codegym.task.task13.task1308;

/* 
Hey, are you alive?

*/

public class Solution {
    public static void main(String[] args) throws Exception {
    }

    interface Person{
        boolean isAlive();
    }

    interface Presentable extends Person{

    }

}