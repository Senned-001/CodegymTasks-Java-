package com.codegym.task.task13.task1328;

public interface CanDefend {
    BodyPart defend();
}
