package com.codegym.task.task13.task1317;

public interface WeatherType {
    String CLOUDY = "Cloudy";
    String FOGGY = "Foggy";
    String FREEZING = "Freezing";
}
