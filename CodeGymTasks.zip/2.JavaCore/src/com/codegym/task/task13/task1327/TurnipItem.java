package com.codegym.task.task13.task1327;

public interface TurnipItem {
    public String getName();
}