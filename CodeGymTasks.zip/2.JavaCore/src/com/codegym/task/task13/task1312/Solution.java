package com.codegym.task.task13.task1312;

/* 
Code doesn't fix itself

*/

public class Solution {
    public static void main(String[] args) {
        Translator translator = new Translator();
        System.out.println(translator.translate());
    }

    public  static class Translator {
        public String translate() {
            return "I translate from Russian";
        }
    }


}