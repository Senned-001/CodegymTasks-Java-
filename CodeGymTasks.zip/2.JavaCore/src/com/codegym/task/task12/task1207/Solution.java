package com.codegym.task.task12.task1207;

/* 
int and Integer

*/

public class Solution {
    public static void main(String[] args) {
        Integer s=10;
        print(5);
        print(s);
    }

    static void print(int a){

    }
    static void print(Integer a){

    }
}
