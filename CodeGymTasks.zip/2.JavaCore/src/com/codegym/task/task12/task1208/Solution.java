package com.codegym.task.task12.task1208;

/* 
Freedom of the press

*/

public class Solution {
    public static void main(String[] args) {

    }

    static void print(int a){

    }
    static void print(Integer a){

    }
    static void print(float a){

    }
    static void print(String a){

    }
    static void print(short a){

    }


}
