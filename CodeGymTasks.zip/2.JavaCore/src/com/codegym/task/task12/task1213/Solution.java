package com.codegym.task.task12.task1213;

/* 
"Fix the code", part 2

*/

public class Solution {
    public static void main(String[] args) {

    }

    public static abstract class Pet {
        public String getName() {
            return "I'm a kitten";
        }

        public abstract Pet getChild();
    }

}
