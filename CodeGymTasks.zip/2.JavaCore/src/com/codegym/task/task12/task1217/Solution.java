package com.codegym.task.task12.task1217;

/* 
Fly, run and swim

*/

public class Solution {
    public static void main(String[] args) {

    }

    public interface CanFly {
        void fly();
    }

    public interface CanRun {
        void run();
    }
    public interface CanSwim {
        void swim();
    }
}
