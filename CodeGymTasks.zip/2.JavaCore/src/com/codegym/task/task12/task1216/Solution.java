package com.codegym.task.task12.task1216;

/* 
Wanna fly?

*/

public class Solution {
    public static void main(String[] args) {

    }

    public interface CanFly{
        void fly();
        int go();
    }

}
