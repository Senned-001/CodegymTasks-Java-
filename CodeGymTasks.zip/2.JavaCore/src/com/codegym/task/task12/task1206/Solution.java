package com.codegym.task.task12.task1206;

/* 
We're on overload!

*/

public class Solution {
    public static void main(String[] args) {

    }

    static void print(int a){

    }
    static void print(String a){

    }

}
