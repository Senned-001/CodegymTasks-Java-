package com.codegym.task.task12.task1210;

/* 
Three methods and a maximum

*/

public class Solution {
    public static void main(String[] args) {

    }
    public static int max(int a, int b){
        if(a<b) return b;
        else
            return a;
    }

    public static long max(long a, long b){
        if(a<b) return b;
        else
            return a;
    }

    public static double max(double a, double b){
        if(a<b) return b;
        else
            return a;
    }
    //write your code here
}
