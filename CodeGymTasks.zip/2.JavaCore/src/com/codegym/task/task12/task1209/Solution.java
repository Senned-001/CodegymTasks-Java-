package com.codegym.task.task12.task1209;

/* 
Three methods and a minimum

*/

public class Solution {
    public static void main(String[] args) {

    }

    static int min(int a, int b){
        if(a<b) return a;
        else
            return b;
    }

    static long min(long a, long b){
        if(a<b) return a;
        else
            return b;
    }

    static double min(double a, double b){
        if(a<b) return a;
        else
            return b;
    }


    //write your code here
}
