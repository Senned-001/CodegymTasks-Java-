package com.codegym.task.task11.task1115;

/* 
From student to skilled slave

*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Schoolboy {

    }

    public class Student extends Schoolboy{

    }

    public class Employee extends Student{

    }

    public class Slave extends Employee{

    }

}
