package com.codegym.task.task11.task1119;

/* 
Correct inheritance chain: part 4

*/

public class Solution {
    public static void main(String[] args) {
    }

    public class House {

    }

    public class Cat {

    }

    public class Car {

    }

    public class Dog {

    }
}