package com.codegym.task.task11.task1116;

/* 
Inheritance chain

*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Pet {

    }

    public class Cat extends Pet{

    }

    public class Dog extends Pet{

    }
}
