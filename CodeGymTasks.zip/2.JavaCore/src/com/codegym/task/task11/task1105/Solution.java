package com.codegym.task.task11.task1105;

/* 
IT company

*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Employee {

    }

    public class Clerk extends Employee{

    }

    public class ITSpecialist extends Employee{

    }

    public class Programmer extends ITSpecialist{

    }

    public class ProjectManager extends ITSpecialist{

    }

    public class CTO extends ITSpecialist{

    }

    public class OfficeManager extends Clerk{

    }

    public class Recruiter extends Clerk{

    }

    public class Custodian extends Clerk{

    }
}
