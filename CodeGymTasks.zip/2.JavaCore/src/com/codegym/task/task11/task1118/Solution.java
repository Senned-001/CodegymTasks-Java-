package com.codegym.task.task11.task1118;

/* 
Urban household

*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Pet {

    }

    public class Cat extends Pet{

    }

    public class Car {

    }

    public class Dog extends Pet{

    }
}
