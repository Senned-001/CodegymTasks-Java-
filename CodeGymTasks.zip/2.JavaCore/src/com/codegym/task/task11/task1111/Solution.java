package com.codegym.task.task11.task1111;

/* 
"He took one of his ribs"

*/

public class Solution {
    public static void main(String[] args) {
    }

    // Adam
    public class Adam {

    }

    // Eve
    public class Eve extends Adam{

    }
}
