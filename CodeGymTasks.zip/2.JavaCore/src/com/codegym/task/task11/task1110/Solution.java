package com.codegym.task.task11.task1110;

/* 
Don't forget to encapsulate

*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Cat {

        private String name;
        private int age;
        private int weight;
        private int speed;

        public Cat(String name, int age, int weight) {

        }

        public String getName() {
            return null;
        }

        public int getAge() {
            return 0;
        }

        public void setWeight(int weight) {

        }

        public void setSpeed(int speed) {

        }
    }
}
