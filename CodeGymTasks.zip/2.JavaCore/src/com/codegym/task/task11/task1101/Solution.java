package com.codegym.task.task11.task1101;

/* 
Horse and Pegasus

*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Horse {

    }

    public class Pegasus extends Horse{

    }
}
