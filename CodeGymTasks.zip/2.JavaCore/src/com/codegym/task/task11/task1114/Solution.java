package com.codegym.task.task11.task1114;

/* 
Evolving classes

*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Fish {

    }

    public class Lizard extends Fish{

    }

    public class Dinosaur extends Lizard{

    }
}
