package com.codegym.task.task11.task1104;

/* 
Hard workers

*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Manager extends Employee{

    }

    public class CEO extends Employee{

    }

    public class Employee {

    }

    public class Secretary extends Employee{

    }
}
