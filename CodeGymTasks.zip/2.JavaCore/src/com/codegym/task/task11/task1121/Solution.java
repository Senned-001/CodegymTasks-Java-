package com.codegym.task.task11.task1121;

/* 
Strange unfamiliar code

*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Pet  {

    }

    public class Cat extends Pet {

    }

    public class Dog extends Pet {

    }

    public class House  {

    }

    public class Airplane {

    }
}
