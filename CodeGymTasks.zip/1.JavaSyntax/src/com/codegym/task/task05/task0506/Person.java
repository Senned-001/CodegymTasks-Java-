package com.codegym.task.task05.task0506;

/* 
People

*/

public class Person {
    String name,address;
    int age;
    char sex;

    public static void main(String[] args) {

    }
}
