package com.codegym.task.task05.task0503;


/* 
Getters and setters for the Dog class

*/

public class Dog {
    String name;
    int age;

    public void setName (String name){
        this.name = name;
    }
    public String getName (){
        return this.name;
    }

    public void setAge(int age){
       this.age=age;
    }
    public int getAge(){
        return this.age;
    }

    public static void main(String[] args) {

    }
}
