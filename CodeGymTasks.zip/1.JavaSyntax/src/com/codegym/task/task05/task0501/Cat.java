package com.codegym.task.task05.task0501;

/* 
Creating a cat

*/

public class Cat {
    String name;
    int age, weight, strength;

    public static void main(String[] args) {

    }
}
