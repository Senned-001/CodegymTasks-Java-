package com.codegym.task.task10.task1004;

/* 
Task No. 4 about integer type conversions

*/

public class Solution {
    public static void main(String[] args) {
        short number = 9;
        char zero = '0';
        int nine = (zero + number);
        System.out.println((char)nine);
    }
}
