package com.codegym.task.task06.task0618;

/* 
KissMyShinyMetalRearActuator

*/

public class Solution {
    public static class KissMyShinyMetalRearActuator {

    }

    public static void main(String[] args) {
        KissMyShinyMetalRearActuator s = new KissMyShinyMetalRearActuator();
        System.out.println(s);
    }
}
