package com.codegym.task.task06.task0601;

/* 
Cat's finalize method

*/

public class Cat {
    protected void finalize() throws Throwable{}
    public static void main(String[] args) {

    }
}
