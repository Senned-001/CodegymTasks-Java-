package com.codegym.task.task06.task0607;

/* 
Class counter

*/

public class Cat {
    static int catCount;
    public Cat(){
        catCount++;
    }

    public static void main(String[] args) {

    }
}
