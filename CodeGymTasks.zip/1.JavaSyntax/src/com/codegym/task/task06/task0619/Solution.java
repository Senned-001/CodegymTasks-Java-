package com.codegym.task.task06.task0619;

/* 
Three static name variables

*/

public class Solution {
    public static String name;
    public static class Cat {
        public static String name;
    }

    public static class Dog {
        public static String name;
    }

    public static void main(String[] args) {

    }
}
