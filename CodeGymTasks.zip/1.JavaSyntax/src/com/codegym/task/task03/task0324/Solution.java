package com.codegym.task.task03.task0324;

/* 
Mercantile intentions

*/

public class Solution {
    public static void main(String[] args) {
        for(int i=0;i<10;i++)
            System.out.println("I want a big salary, and that's why I'm studying Java");
    }
}
