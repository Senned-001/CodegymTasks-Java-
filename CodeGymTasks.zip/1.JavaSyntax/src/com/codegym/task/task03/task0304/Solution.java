package com.codegym.task.task03.task0304;

/* 
Task with percentages

*/

public class Solution {
    public static double addTenPercent(int i) {
        double inc;
        return inc = i + i*0.1;
    }

    public static void main(String[] args) {
        System.out.println(addTenPercent(9));
    }
}
