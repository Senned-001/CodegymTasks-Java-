package com.codegym.task.task03.task0317;

/* 
The way of the Samurai

*/

public class Solution {
    public static void main(String[] args) {
        System.out.println("日本語");
    }
}
