package com.codegym.task.task03.task0309;

/* 
Sum of 5 numbers

*/

public class Solution {
    public static void main(String[] args) {
        int s=1;
        System.out.println(s);
        System.out.println(s=s+2);
        System.out.println(s=s+3);
        System.out.println(s=s+4);
        System.out.println(s=s+5);
    }
}
