package com.codegym.task.task03.task0313;

/* 
Sam I Am

*/

public class Solution {
    public static void main(String[] args) {
        String a="Sam", b="Am", c="I";
        System.out.println(a+b+c);
        System.out.println(a+c+b);
        System.out.println(b+c+a);
        System.out.println(b+a+c);
        System.out.println(c+b+a);
        System.out.println(c+a+b);
    }
}
