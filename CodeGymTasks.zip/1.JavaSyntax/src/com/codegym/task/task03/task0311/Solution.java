package com.codegym.task.task03.task0311;

/* 
Printing strings

*/

public class Solution {
    public static void main(String[] args) {
        writeToConsole("Hello, World!");
    }

    public static void writeToConsole(String s) {
        String t = "printing: " + s;
        System.out.println(t);
    }
}
