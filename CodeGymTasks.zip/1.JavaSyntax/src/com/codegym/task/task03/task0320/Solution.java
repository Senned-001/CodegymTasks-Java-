package com.codegym.task.task03.task0320;


/* 
The humble programmer

*/

import java.io.*;

public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String name = reader.readLine();


        System.out.print(name + " makes $120,000 a year. Ha-ha-ha!");
    }
}
