package com.codegym.task.task03.task0305;

/* 
Red scare

*/

public class Solution {
    public static void main(String[] args) {
        System.out.println("MAY" + " " + 22 + " " + 1988);
    }
}
