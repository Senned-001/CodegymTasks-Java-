package com.codegym.task.task03.task0308;

/* 
Product of 10 numbers

*/

public class Solution {
    public static void main(String[] args) {
        int p = 1*2*3*4*5*6*7*8*9*10;
        System.out.println(p);
    }
}
