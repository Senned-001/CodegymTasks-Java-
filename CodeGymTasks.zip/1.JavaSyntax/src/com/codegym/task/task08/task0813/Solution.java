package com.codegym.task.task08.task0813;

import java.util.*;

/* 
20 words that start with the letter "L"

*/

public class Solution {
    public static Set<String> createSet() {
        HashSet<String> set = new HashSet<String>();


        set.add("Letter");
        set.add("List");
        set.add("Loop");
        set.add("Lo");
        set.add("La");
        set.add("Ly");
        set.add("Lu");
        set.add("Li");
        set.add("Lp");
        set.add("Ls");
        set.add("Ld");
        set.add("Lf");
        set.add("Lg");
        set.add("Lh");
        set.add("Lk");
        set.add("Ll");
        set.add("Lz");
        set.add("Lx");
        set.add("Lb");
        set.add("Ln");


        return set;
    }

    public static void main(String[] args) {

    }
}
