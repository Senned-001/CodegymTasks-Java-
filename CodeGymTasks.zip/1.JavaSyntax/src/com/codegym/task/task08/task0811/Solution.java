package com.codegym.task.task08.task0811;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/* 
Method quartet

*/

public class Solution {
    public static List getListForGet() {
        ArrayList list = new ArrayList();
        return list;

    }

    public static List getListForSet() {
        ArrayList list = new ArrayList();
        return list;
    }

    public static List getListForAddOrInsert() {
        LinkedList list = new LinkedList();
        return list;
    }

    public static List getListForRemove() {
        LinkedList list = new LinkedList();
        return list;

    }

    public static void main(String[] args) {

    }
}
