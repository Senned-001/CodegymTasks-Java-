package com.codegym.task.task08.task0807;

import java.util.*;

/* 
LinkedList and ArrayList

*/

public class Solution {
    public static Object createArrayList() {
        ArrayList<String> list = new ArrayList<>();
        return list;

    }

    public static Object createLinkedList() {
        LinkedList<String> llist = new LinkedList<>();
        return llist;

    }

    public static void main(String[] args) {

    }
}
