package com.codegym.task.task04.task0437;


/* 
Triangle of eights

*/

public class Solution {
    public static void main(String[] args) throws Exception {
        String s ="8";
        for(int i=0;i<10;i++) {
            {System.out.println(s);s=s+"8";}
        }

    }
}
