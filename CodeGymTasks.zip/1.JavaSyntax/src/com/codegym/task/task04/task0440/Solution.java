package com.codegym.task.task04.task0440;

/* 
Decent pay

*/

public class Solution {
    public static void main(String[] args) {
        for(int i=0;i<100;i++)
            System.out.println("I will never work for peanuts. Amigo");
    }
}
