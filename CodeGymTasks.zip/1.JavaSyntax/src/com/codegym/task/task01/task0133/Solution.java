package com.codegym.task.task01.task0133;

/* 
Don't think about seconds…

*/

public class Solution {
    public static void main(String[] args) {
        int secondsAfter15 = 30*60;
        System.out.println(secondsAfter15);

    }
}